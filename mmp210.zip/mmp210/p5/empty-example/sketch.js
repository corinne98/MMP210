var r1=0;
var r2=0;

function setup() {
  // put setup code here
    createCanvas(720,400);
    noStroke();
    rectMode(CENTER);
}

function draw() {
  // put drawing code here
    background(0);
    
//    var r1 = map(mouseX,0,width,0,height);
//    var r2 = height - r1;
//    
//    fill(237,34,93,r1);
//    rect(width/2 + r1/2, height/2, r1, r1);
//    
//    fill(237,34,93,r2);
//    rect(width/2 + r2/2, height/2, r2, r2);

}